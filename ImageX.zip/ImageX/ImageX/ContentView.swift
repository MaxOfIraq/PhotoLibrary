//
//  ContentView.swift
//  ImageX
//
//  Created by Ahmed Salah on 16/09/2022.
//

import SwiftUI

struct ContentView: View {
    
    var image1 = UIImage(named: "icon1")!
    var image2 = UIImage(named: "icon2")!
    var image3 = UIImage(named: "icon3")!
    var image4 = UIImage(named: "icon4")!
    var image5 = UIImage(named: "icon5")!
    
    
    var body: some View {
        
        NavigationView{
            ScrollView(showsIndicators: false){
                VStack{
                    
                    
                    
                    Image(uiImage: image1)
                        .resizable()
                        .scaleEffect()
                        .frame(width: 250, height: 500)
                        .cornerRadius(10)
                    
                    Button("Download Image"){
                        UIImageWriteToSavedPhotosAlbum(image1, nil, nil, nil)
                    }.padding()
                    
                    
                    
                    
                    Image(uiImage: image2)
                        .resizable()
                        .scaleEffect()
                        .frame(width: 250, height: 500)
                        .cornerRadius(10)
                    
                    Button("Download Image"){
                        UIImageWriteToSavedPhotosAlbum(image2, nil, nil, nil)
                    }.padding()
                    
                    
                    
                    
                    
                    Image(uiImage: image3)
                        .resizable()
                        .scaleEffect()
                        .frame(width: 250, height: 500)
                        .cornerRadius(10)
                    
                    Button("Download Image"){
                        UIImageWriteToSavedPhotosAlbum(image3, nil, nil, nil)
                    }.padding()
                    
                    
                    
                    
                    
                    Image(uiImage: image4)
                        .resizable()
                        .scaleEffect()
                        .frame(width: 250, height: 500)
                        .cornerRadius(10)
                    
                    Button("Download Image"){
                        UIImageWriteToSavedPhotosAlbum(image4, nil, nil, nil)
                    }.padding()
                    
                    
                    
                    
                    Image(uiImage: image5)
                        .resizable()
                        .scaleEffect()
                        .frame(width: 250, height: 500)
                        .cornerRadius(10)
                    
                    Button("Download Image"){
                        UIImageWriteToSavedPhotosAlbum(image5, nil, nil, nil)
                    }.padding()
                    
                    
                    
                    
                    
                }
            }.navigationTitle("Wallpaper")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
