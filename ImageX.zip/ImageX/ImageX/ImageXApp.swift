//
//  ImageXApp.swift
//  ImageX
//
//  Created by Ahmed Salah on 16/09/2022.
//

import SwiftUI

@main
struct ImageXApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
